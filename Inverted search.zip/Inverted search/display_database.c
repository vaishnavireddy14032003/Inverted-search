#include "header.h"

/* ================= DISPLAY DATABASE ================= */

void display_database()
{
    int empty = 1;

    printf("\n=================================================================================================\n");
    printf("Index\tWord\t\tFilecount\tFilename\t\tWordcount\n");
    printf("=================================================================================================\n");

    for (int i = 0; i < SIZE; i++)
    {
        word_node *temp = hash_table[i];

        while (temp != NULL)
        {
            empty = 0;

            file_node *f_temp = temp->file_list;

            /* First file prints with word details */
            if (f_temp != NULL)
            {
                printf("%d\t%-15s\t%d\t\t%-20s\t%d\n",
                        i,
                        temp->word,
                        temp->file_count,
                        f_temp->filename,
                        f_temp->word_count);

                f_temp = f_temp->next;
            }

            /* Remaining files */
            while (f_temp != NULL)
            {
                printf("\t\t\t\t%-20s\t%d\n",
                        f_temp->filename,
                        f_temp->word_count);

                f_temp = f_temp->next;
            }

            temp = temp->next;
        }
    }

    if (empty)
    {
        printf("Database is empty!\n");
    }

    printf("=================================================================================================\n");
}