#include "header.h"

/* ================= SAVE DATABASE TO FILE ================= */

void save_database(char *output_filename)
{
    FILE *fp = fopen(output_filename, "w");

    if (fp == NULL)
    {
        printf("ERROR: Cannot open file %s for writing\n", output_filename);
        return;
    }

    int empty = 1;

    fprintf(fp, "========== INVERTED INDEX DATABASE ==========\n\n");

    for (int i = 0; i < SIZE; i++)
    {
        word_node *wtemp = hash_table[i];

        while (wtemp != NULL)
        {
            empty = 0;

            fprintf(fp, "%s -> ", wtemp->word);

            file_node *ftemp = wtemp->file_list;

            while (ftemp != NULL)
            {
                fprintf(fp, "%s ", ftemp->filename);
                ftemp = ftemp->next;
            }

            fprintf(fp, "\n");

            wtemp = wtemp->next;
        }
    }

    if (empty)
    {
        fprintf(fp, "Database is empty!\n");
    }

    fclose(fp);

    printf("Database successfully saved to file: %s\n", output_filename);
}