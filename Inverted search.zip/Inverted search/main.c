/*
NAME : VAISHNAVI REDDY
DATE : 22/05/2026
PROJECT : INVERTED SEARCH
*/
#include "header.h"

/* ================= GLOBAL HASH TABLE ================= */

word_node *hash_table[SIZE] = {NULL};

/* ================= MAIN ================= */

int main(int argc, char *argv[])
{
    int choice;
    char word[50];

    /* ---------------- ARGUMENT VALIDATION ---------------- */
    if (argc < 2)
    {
        printf("ERROR: No files provided!\n");
        printf("Usage: %s <file1> <file2> ...\n", argv[0]);
        return 1;
    }

    /* ---------------- DISPLAY FILE LIST ---------------- */
    printf("\n========== FILE LIST ==========\n");
    for (int i = 1; i < argc; i++)
    {
        printf("%d. %s\n", i, argv[i]);
    }

    /* ================= MENU LOOP ================= */
    while (1)
    {
        printf("\n========== INVERTED SEARCH MENU ==========\n");
        printf("1. Create Database\n");
        printf("2. Display Database\n");
        printf("3. Search Word\n");
        printf("4. Update Database\n");
        printf("5. Save Database\n");
        printf("6. Exit\n");

        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
        /* -------- CREATE DATABASE (ALL FILES) -------- */
        case 1:
        {
            int status = FAILURE;

            for (int i = 1; i < argc; i++)
            {
                status = create_database(argv[i]);
            }

            if (status == SUCCESS)
                printf("Database created successfully!\n");
            else
                printf("Database creation failed!\n");

            break;
        }

        /* -------- DISPLAY DATABASE -------- */
        case 2:
            display_database();
            break;

        /* -------- SEARCH WORD -------- */
        case 3:
            printf("Enter word to search: ");
            scanf("%s", word);

            for (int i = 0; word[i]; i++)
                word[i] = tolower(word[i]);

            search_word(word);
            break;

        /* -------- UPDATE DATABASE -------- */
        case 4:
        {
            char new_file[50];

            printf("Enter new filename to update: ");
            scanf("%s", new_file);

            if (create_database(new_file) == SUCCESS)
                printf("Database updated successfully!\n");
            else
                printf("Update failed!\n");

            break;
        }

        /* -------- SAVE DATABASE -------- */
        case 5:
            save_database("index.txt");
            printf("Database saved to index.txt\n");
            break;

        /* -------- EXIT -------- */
        case 6:
            printf("Exiting program...\n");
            exit(0);

        default:
            printf("Invalid choice!\n");
        }
    }

    return 0;
}