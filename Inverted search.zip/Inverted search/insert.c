#include "header.h"

void insert_word(char *word, char *filename)
{
    int index = hash_function(word);

    word_node *temp = hash_table[index];

    /* word already exists */
    while (temp != NULL)
    {
        if (strcmp(temp->word, word) == 0)
        {
            add_file(temp, filename);
            return;
        }

        temp = temp->next;
    }

    /* create new word node */
    word_node *new = malloc(sizeof(word_node));

    strcpy(new->word, word);

    new->file_count = 0;

    new->file_list = NULL;

    new->next = hash_table[index];

    hash_table[index] = new;

    /* add first file */
    add_file(new, filename);
}