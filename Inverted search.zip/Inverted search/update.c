#include "header.h"

/* ================= CHECK IF FILE ALREADY PROCESSED ================= */

static int is_file_already_added(char *filename)
{
    for (int i = 0; i < SIZE; i++)
    {
        word_node *wtemp = hash_table[i];

        while (wtemp != NULL)
        {
            file_node *ftemp = wtemp->file_list;

            while (ftemp != NULL)
            {
                if (strcmp(ftemp->filename, filename) == 0)
                {
                    return 1;   // file already exists in database
                }
                ftemp = ftemp->next;
            }

            wtemp = wtemp->next;
        }
    }

    return 0;
}

/* ================= UPDATE DATABASE ================= */

void update_database(char *filename)
{
    /* check duplicate file */
    if (is_file_already_added(filename))
    {
        printf("WARNING: File '%s' already exists in database!\n", filename);
        return;
    }

    /* reuse create_database logic */
    create_database(filename);

    printf("Database updated successfully with file: %s\n", filename);
}
