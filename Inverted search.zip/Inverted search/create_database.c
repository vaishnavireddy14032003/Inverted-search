#include "header.h"

/* function to remove special characters */
void clean_word(char *word)
{
    int i, j = 0;
    char temp[50];

    for(i = 0; word[i] != '\0'; i++)
    {
        if(isalnum(word[i]))
        {
            temp[j++] = tolower(word[i]);
        }
    }

    temp[j] = '\0';

    strcpy(word, temp);
}

int create_database(char *filename)
{
    FILE *fp = fopen(filename, "r");

    if (fp == NULL)
    {
        printf("ERROR: Cannot open file %s\n", filename);
        return FAILURE;
    }

    char word[50];

    while (fscanf(fp, "%s", word) != EOF)
    {
        clean_word(word);

        /* avoid empty strings */
        if(strlen(word) > 0)
        {
            insert_word(word, filename);
        }
    }

    fclose(fp);

    return SUCCESS;
}