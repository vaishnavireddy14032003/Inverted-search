#include "header.h"

/* ================= ADD FILE TO WORD NODE ================= */

void add_file(word_node *word_node_ptr, char *filename)
{
    file_node *temp = word_node_ptr->file_list;

    /* check duplicate file */
    while (temp != NULL)
    {
        /* same file found */
        if (strcmp(temp->filename, filename) == 0)
        {
            temp->word_count++;   // increase word count
            return;
        }

        temp = temp->next;
    }

    /* create new file node */
    file_node *new = (file_node *)malloc(sizeof(file_node));

    strcpy(new->filename, filename);

    new->word_count = 1;   // first occurrence

    new->next = word_node_ptr->file_list;
    word_node_ptr->file_list = new;

    /* increase file count */
    word_node_ptr->file_count++;
}