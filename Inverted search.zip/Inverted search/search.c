#include "header.h"

/* ================= SEARCH WORD ================= */

void search_word(char *word)
{
    int index = hash_function(word);

    word_node *temp = hash_table[index];

    while (temp != NULL)
    {
        if (strcmp(temp->word, word) == 0)
        {
            printf("\nWord '%s' found in files:\n", word);

            file_node *f_temp = temp->file_list;

            while (f_temp != NULL)
            {
                printf("-> %s\n", f_temp->filename);
                f_temp = f_temp->next;
            }

            return;
        }

        temp = temp->next;
    }

    printf("\nWord '%s' not found in database!\n", word);
}
