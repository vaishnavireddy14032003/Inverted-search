#include "header.h"

/* ================= HASH FUNCTION ================= */

int hash_function(char *word)
{
    return tolower(word[0]) - 'a';
}