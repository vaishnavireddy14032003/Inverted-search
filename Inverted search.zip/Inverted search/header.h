#ifndef HEADER_H
#define HEADER_H

/* ================= STANDARD LIBRARIES ================= */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/* ================= MACROS ================= */

#define SIZE 26

#define SUCCESS 0
#define FAILURE -1
#define FILE_NOT_FOUND -2
#define DUPLICATE -3
#define EMPTY_DB -4

/* ================= STRUCTURES ================= */

/* File linked list node */
typedef struct file_node
{
    char filename[50];
    int word_count;              
    struct file_node *next;

} file_node;

/* Word linked list node */
typedef struct word_node
{
    char word[50];
    int file_count;              

    file_node *file_list;
    struct word_node *next;

} word_node;

/* ================= GLOBAL VARIABLE ================= */

extern word_node *hash_table[SIZE];

/* ================= FUNCTION DECLARATIONS ================= */

/* Hash function */
int hash_function(char *word);

/* Core functions */
void insert_word(char *word, char *filename);
void add_file(word_node *word_node_ptr, char *filename);

/* Database operations */
int create_database(char *filename);
void display_database();
void search_word(char *word);

/* Extra features */
void update_database(char *filename);
void save_database(char *filename);

#endif